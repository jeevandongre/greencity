<?php
	include("common.inc");
	header("Location:success.php?msg=SQT");
?>